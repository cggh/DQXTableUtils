from distutils.core import setup

setup(
    name='DQXTableUtils',
    version='0.1.0',
    packages=['DQXTableUtils'],
    description='Useful towel-related stuff.',
    install_requires=[
        "xlrd>=0.9.2",
    ],
)
